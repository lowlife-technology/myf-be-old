-- AlterTable
ALTER TABLE "Category" ALTER COLUMN "deletedAt" DROP NOT NULL;
